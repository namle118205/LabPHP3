<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Hồ sơ cá nhân</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <!-- Header Top -->
    <header class="bg-white border-b border-gray-200">
        <div class="container mx-auto flex justify-between items-center py-3">
            <div class="flex items-center space-x-2">
                <a href="<?php echo e(route('home')); ?>" class="flex items-center space-x-2">
                    <img src="<?php echo e(asset('image/Screenshot 2025-03-21 020815.png')); ?>" alt="Logo" class="h-14">
                </a>
                <span class="text-sm text-gray-500 hidden md:inline">
                    <?php echo e(\Illuminate\Support\Str::title(\Carbon\Carbon::now()->translatedFormat('l'))); ?>,
                    <?php echo e(\Carbon\Carbon::now()->format('d/m/Y')); ?>

                </span>
            </div>

            <div class="flex items-center space-x-4">
                <form action="<?php echo e(route('search')); ?>" method="GET" class="flex">
                    <input type="text" name="keyword" placeholder="Tìm kiếm..." value="<?php echo e(request('keyword')); ?>"
                        class="border rounded-l px-2 py-1 text-sm focus:outline-none">
                    <button type="submit"
                        class="bg-gray-600 text-white px-3 rounded-r text-sm hover:bg-blue-700">Tìm</button>
                </form>

                <nav class="d-flex align-items-center gap-2">
                    <?php if(Auth::check()): ?>
                        <div class="dropdown">
                            <button class="btn btn-link text-dark text-decoration-none dropdown-toggle"
                                type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?>

                            </button>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>">Thông tin tài khoản</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">Chỉnh sửa tài khoản</a></li>
                                <?php if(Auth::user()->role === 'admin'): ?>
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">Quản trị viên</a></li>
                                <?php endif; ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Đăng xuất</a></li>
                            </ul>
                        </div>                                     
                    <?php else: ?>
                        <a href="<?php echo e(route('login.form')); ?>" class="text-dark text-decoration-none">Đăng nhập</a>
                        <a href="<?php echo e(route('register.form')); ?>" class="text-dark text-decoration-none">Đăng ký</a>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </header>

    <!-- Nav Category -->
    <nav class="bg-gray-50 border-b border-gray-200">
        <div class="container mx-auto flex space-x-6 py-2 overflow-x-auto">
            <a href="<?php echo e(route('home')); ?>" class="flex items-center space-x-1 text-gray-700 hover:text-blue-600 text-decoration-none">
                <span>Trang chủ</span>
            </a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('category', $category->id)); ?>"
                    class="text-gray-700 hover:text-blue-600 text-decoration-none whitespace-nowrap"><?php echo e($category->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </nav>

    <!-- Main content -->
    <main class="container mx-auto mt-6 flex-grow flex">
        <!-- Sidebar trái -->
        <div class="w-1/4 bg-white shadow-lg p-6">
            <h2 class="text-xl font-bold mb-6 text-black">Menu cá nhân</h2>
            <ul class="space-y-4">
                <li>
                    <a href="<?php echo e(route('profile.show')); ?>" 
                       class="block px-4 py-2 rounded text-black hover:text-blue-500 hover:bg-blue-100 text-decoration-none <?php echo e(Route::is('profile.show') ? 'bg-blue-100 text-blue-500' : ''); ?>">
                        Thông tin tài khoản
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('profile.edit')); ?>" 
                       class="block px-4 py-2 rounded text-black hover:text-blue-500 hover:bg-blue-100 text-decoration-none <?php echo e(Route::is('profile.edit') ? 'bg-blue-100 text-blue-500' : ''); ?>">
                        Chỉnh sửa tài khoản
                    </a>
                </li>
                <?php if(Auth::user()->role === 'admin'): ?>
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" 
                           class="block px-4 py-2 rounded text-black hover:text-blue-500 hover:bg-blue-100 text-decoration-none <?php echo e(Route::is('admin.dashboard') ? 'bg-blue-100 text-blue-500' : ''); ?>">
                            Quản trị viên
                        </a>
                    </li>
                <?php endif; ?>
                <li>
                    <a href="<?php echo e(route('logout')); ?>" 
                       class="block px-4 py-2 rounded text-black hover:text-blue-500 hover:bg-blue-100 no-underline">
                        Đăng xuất
                    </a>
                </li>
            </ul>
        </div>

        <!-- Nội dung chính bên phải -->
        <div class="w-3/4 pl-4">
            <?php echo $__env->yieldContent('profile-content'); ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-700 text-white text-center p-4 mt-10">
        © 2025 - Laravel News Website
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\LabPHP3\Assignment2_PA00280LeThanhNam\resources\views\layouts\profile.blade.php ENDPATH**/ ?>