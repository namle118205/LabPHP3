

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4"><?php echo e($category->name); ?></h1>

    <?php if($posts->count()): ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white shadow rounded p-4">
                    <a href="<?php echo e(route('post.detail', $post->id)); ?>" class="block hover:opacity-80">
                        <img src="<?php echo e(asset('image/'.$post->image)); ?>" alt="<?php echo e($post->title); ?>" class="w-full h-40 object-cover rounded">
                        <h2 class="mt-2 font-semibold text-lg"><?php echo e($post->title); ?></h2>
                        <p class="text-sm text-gray-600"><?php echo e(\Illuminate\Support\Str::limit($post->description, 100)); ?></p>
                    </a>
                    <div class="text-sm text-gray-500 mt-1"><?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d/m/Y')); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <div class="mt-6">
            <?php echo e($posts->links()); ?>

        </div>
    <?php else: ?>
        <p>Không có bài viết nào trong danh mục này.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LabPHP3\Assignment2_PA00280LeThanhNam\resources\views\post\show.blade.php ENDPATH**/ ?>