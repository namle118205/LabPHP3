

<?php $__env->startSection('content'); ?>
<div class="max-w-md mx-auto mt-10 p-6 bg-white rounded shadow">
    <h2 class="text-xl font-bold mb-4">Quên mật khẩu</h2>
    <?php if(session('success')): ?> <p class="text-green-500"><?php echo e(session('success')); ?></p> <?php endif; ?>
    <?php if(session('error')): ?> <p class="text-red-500"><?php echo e(session('error')); ?></p> <?php endif; ?>

    <form method="POST" action="<?php echo e(route('forgot.send')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label>Email</label>
            <input type="email" name="email" class="w-full border rounded p-2" required>
        </div>
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Gửi yêu cầu</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LabPHP3\Assignment2_PA00280LeThanhNam\resources\views\auth\forgot-password.blade.php ENDPATH**/ ?>