<!-- resources/views/post/detail.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto bg-white p-6 rounded shadow">
        <h1 class="text-3xl font-bold mb-2"><?php echo e($post->title); ?></h1>
        <p class="text-gray-600 mb-4">Đăng ngày: <?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d/m/Y')); ?> | Lượt xem:
            <?php echo e($post->views); ?></p>
        <div class="mb-6">
            <img src="<?php echo e(asset('image/' . $post->image)); ?>" alt="<?php echo e($post->title); ?>" class="w-full rounded mb-4">
            <p><?php echo nl2br($post->content); ?></p>
        </div>

        <!-- Phần bình luận -->
        <h2 class="text-xl font-bold mb-4">Bình luận</h2>

        <?php if(auth()->guard()->guest()): ?>
            <p class="text-red-500">Bạn cần <a href="<?php echo e(route('login.form')); ?>" class="underline text-blue-600">đăng nhập</a> để
                bình luận.</p>
        <?php else: ?>
            <form action="<?php echo e(route('comment.store', $post->id)); ?>" method="POST" class="mb-6">
                <?php echo csrf_field(); ?>
                <textarea name="content" rows="3" class="w-full border p-2 rounded" placeholder="Nhập bình luận..." required></textarea>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 mt-2 rounded">Gửi bình luận</button>
            </form>
        <?php endif; ?>

        <div class="space-y-4">
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-3 bg-gray-100 rounded">
                    <strong><?php echo e($comment->user_name); ?></strong>
                    <span
                        class="text-sm text-gray-500"><?php echo e(\Carbon\Carbon::parse($comment->created_at)->diffForHumans()); ?></span>
                    <p><?php echo e($comment->content); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LabPHP3\Assignment2_PA00280LeThanhNam\resources\views\post\detail.blade.php ENDPATH**/ ?>