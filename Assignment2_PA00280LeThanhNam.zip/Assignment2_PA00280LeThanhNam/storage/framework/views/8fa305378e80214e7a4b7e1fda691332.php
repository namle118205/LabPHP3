

<?php $__env->startSection('content'); ?>
    <h2 class="text-2xl font-bold mb-4">Kết quả tìm kiếm cho: "<?php echo e($query); ?>"</h2>

    <?php if($posts->count()): ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white p-4 shadow rounded">
                    <a href="<?php echo e(route('post.detail', $post->id)); ?>">
                        <img src="<?php echo e(asset('image/' . $post->image)); ?>" alt="<?php echo e($post->title); ?>" class="w-full h-48 object-cover mb-3 rounded">
                    </a>
                    <h3 class="font-semibold text-lg mb-2"><?php echo e($post->title); ?></h3>
                    <p><?php echo e(Str::limit($post->description, 100)); ?></p>
                    <a href="<?php echo e(route('post.detail', $post->id)); ?>" class="text-blue-600">Xem chi tiết</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <p>Không tìm thấy kết quả nào cho từ khoá "<?php echo e($query); ?>".</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LabPHP3\Assignment2_PA00280LeThanhNam\resources\views\search.blade.php ENDPATH**/ ?>