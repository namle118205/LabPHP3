

<?php $__env->startSection('admin_content'); ?>
    <h1 class="text-2xl font-bold">Bảng điều khiển</h1>
    <p>Chào mừng đến với khu vực quản trị!</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LabPHP3\Assignment2_PA00280LeThanhNam\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>