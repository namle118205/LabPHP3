

<?php $__env->startSection('profile-content'); ?>
<div class="bg-white rounded-lg shadow-lg p-6 max-w-2xl">
    <!-- Header -->
    <div class="flex items-center justify-between border-b pb-4 mb-6">
        <h2 class="text-2xl font-semibold text-gray-800">Thông tin cá nhân</h2>
        <a href="<?php echo e(route('profile.edit')); ?>" 
           class="text-blue-600 hover:text-blue-800 text-sm font-medium">
            Chỉnh sửa
        </a>
    </div>

    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Profile Information -->
    <div class="space-y-6">
        <div class="flex items-center">
            <span class="w-32 text-gray-600 font-medium">Họ tên:</span>
            <span class="text-gray-800"><?php echo e(Auth::user()->name); ?></span>
        </div>
        <div class="flex items-center">
            <span class="w-32 text-gray-600 font-medium">Email:</span>
            <span class="text-gray-800"><?php echo e(Auth::user()->email); ?></span>
        </div>
        <div class="flex items-center">
            <span class="w-32 text-gray-600 font-medium">Vai trò:</span>
            <span class="text-gray-800">
                <?php echo e(Auth::user()->role === 'client' ? 'Khách hàng' : 'Quản trị viên'); ?>

            </span>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LabPHP3\Assignment2_PA00280LeThanhNam\resources\views\profile\show.blade.php ENDPATH**/ ?>