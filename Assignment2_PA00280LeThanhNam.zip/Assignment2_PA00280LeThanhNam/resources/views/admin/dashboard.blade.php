@extends('layouts.admin')

@section('admin_content')
    <h1 class="text-2xl font-bold">Bảng điều khiển</h1>
    <p>Chào mừng đến với khu vực quản trị!</p>
@endsection