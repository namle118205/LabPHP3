<p>Chào bạn {{ Auth::user()->name }}</p>
Đây là trang quản trị chỉ dành cho admin