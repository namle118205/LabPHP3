<p>Chào bạn <?php echo e(Auth::user()->name); ?></p>
Đây là trang download software, chỉ dành cho thành viên đăng nhập
<form method="POST" action="/logout">
    <?php echo csrf_field(); ?>
    <button type="submit">Thoát</button>
</form><?php /**PATH C:\xampp\htdocs\LabPHP3\Lab6_PA00280LeThanhNam\resources\views/download.blade.php ENDPATH**/ ?>